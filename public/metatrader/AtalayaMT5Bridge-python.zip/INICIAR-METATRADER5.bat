@echo off
title ATALAYA - puente MetaTrader 5
cd /d "%~dp0"
echo ATALAYA Financial - puente MetaTrader 5 (solo lectura / read-only)
echo Abre MetaTrader 5 con tu cuenta antes de continuar. / Open MetaTrader 5 first.
echo.
where python >nul 2>nul || (echo No encuentro Python. Instalalo desde https://www.python.org/downloads/ marcando "Add Python to PATH". & pause & exit /b 1)
python -c "import MetaTrader5" 2>nul || (echo Instalando el paquete oficial MetaTrader5... & python -m pip install --user MetaTrader5)
python mt5_bridge.py
pause
