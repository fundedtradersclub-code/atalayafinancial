ATALAYA Financial - puente MetaTrader 5 / MetaTrader 5 bridge
https://atalayafinancial.vercel.app

ESPAÑOL
-------
Lleva a ATALAYA los precios en vivo de tu MetaTrader 5 (divisas, oro, plata, índices...).
Es SOLO LECTURA: no envía órdenes, no lee tu saldo ni tus posiciones y no es un Asesor Experto.
Los datos van de tu MetaTrader a tu navegador, dentro de tu computadora. No pasan por internet
ni por el servidor de ATALAYA, y nadie fuera de tu PC puede leerlos.

Requisitos: Windows, MetaTrader 5 y Python 3 (https://www.python.org/downloads/ ,
marca "Add Python to PATH" al instalar).

1. Abre MetaTrader 5 e inicia sesión (una cuenta demo sirve).
2. Haz doble clic en INICIAR-METATRADER5.bat. La primera vez instala el paquete oficial
   MetaTrader5 de MetaQuotes.
3. Deja abierta la ventana negra (puedes minimizarla).
4. Abre https://atalayafinancial.vercel.app en Chrome, Edge o Firefox. Si el navegador pide
   permiso de "acceso a la red local", acéptalo. En Conexiones verás "MetaTrader 5: conectado".

Son precios de tu bróker (CFD): siguen al mercado pero no son idénticos a los futuros de CME.
Solo para uso personal. Si usas una cuenta de fondeo, revisa las reglas de tu firma.

ENGLISH
-------
Brings live prices from your MetaTrader 5 (currencies, gold, silver, indices...) into ATALAYA.
It is READ-ONLY: it sends no orders, does not read your balance or positions and is not an
Expert Advisor. Data travels from your MetaTrader to your browser inside your own computer.
It does not go over the internet or through the ATALAYA server.

Requirements: Windows, MetaTrader 5 and Python 3 (https://www.python.org/downloads/ ,
tick "Add Python to PATH" when installing).

1. Open MetaTrader 5 and log in (a demo account works).
2. Double-click INICIAR-METATRADER5.bat. The first time it installs MetaQuotes' official
   MetaTrader5 package.
3. Keep the black window open (you can minimize it).
4. Open https://atalayafinancial.vercel.app in Chrome, Edge or Firefox. If the browser asks for
   "local network access" permission, allow it. In Connections you will see "MetaTrader 5: connected".

These are your broker's prices (CFDs): they track the market but are not identical to CME futures.
Personal use only. If you trade a funded account, check your firm's rules.

Licencia / License: MIT - @elmigrante.digital (ATALAYA Financial)
